%
% define the mobile robot
% 
function robot=robotspec(rdim)
    robot=collisionBox(rdim(1),rdim(2),rdim(3));
end

