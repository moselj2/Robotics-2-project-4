function []=robotfcn(h_obj,evt)

assignin('base','keyvalue',evt.Key);
assignin('base','keypressed',1);

end