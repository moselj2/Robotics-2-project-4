%
% trajectory optimziation (TrajOpt) Method
% 
% to run: just type in 
% 
% >> trajopt_move
% 

clear all;close all;
addpath(genpath(pwd))

% define room
colobj=roomspec;

% define robot
rL=.4;rW=1;rz=.1;
robot=collisionCylinder(rW,rz);

% now for the rectangular load
%robot=collisionBox(1,0.5,rz);

% initial condition
%q0=[.5;2;0];
q0=[2;2;0];

more_qf=1;

rng(10000);
while more_qf>0
    % check if random qf should be used
    qf_flag=1;
    while qf_flag>0
        qf=[5*rand(1,2)+[5 5] pi*2*(rand-.5)]';
        [isInt,dist,wp]=colcheck(robot,qf,colobj);
        if (max(isnan(dist))==0)&&(min(dist)>rW);qf_flag=0;end
    end    
    %qf=[8.1202;8.7428;1.7421];
    %qf=[5.9889;5.1983;0.4788];
    disp(sprintf('qf = [%0.3g, %0.3g, %0.3g]', qf));

    % trajopt planner (planar translation)
    n=2; % # of states
    x0=q0(1:n);
    xf=qf(1:n);
    N=40; % # of steps in trajectory

    % start from initial location
    xbar0=zeros(n,N+1);
    ubar0=reshape(diff(xbar0')',n*N,1);
    
    % random initial guess
    ubar0=ubar0+rand(N*n,1)*.01;

    epsilon=.1; % weighting on the input
    alpha=1; % maximum step size
    maxiter=20; % maximum iterations
    mu=0.5; % strength of penalty function
    dumx=[.1;.1]*8; % maximum update step size between iterations

    % main iteration routine
    [ubar,xbar,alphaopt,Bbar]=...
        trajiter_EP(robot,colobj,ubar0,x0,xf,epsilon,alpha,maxiter,mu,dumx);

    % Show iteration results
    figure(1);hold on;
    roomshow(colobj,1);axis('square');
    view(-90,90);axis([-1 11 -1 11 0 4])
    robotshow(robot,q0,[.5,.1,.5]);
    robotshow(robot,qf,[.1,.5,.1]);

    % Show final iteration result
    xfinal=xbar(:,maxiter);
    ufinal=reshape(ubar(:,maxiter),n,N);
    xfinalflat=reshape(xfinal,n,N);
    xfinaldiff=diff(xfinalflat')';
    q3final=atan2(xfinaldiff(2,:),xfinaldiff(1,:));
    qfinal=[[xfinalflat xf];[q0(3) q3final qf(3)]];
    
    for i=1:N+1;robotshow(robot,qfinal(:,i));end
    for i=[2,maxiter]
        qbar{i}=xbar_reshape(xbar(:,i),q0,n,N);
        color_code=rand(3,1)*.5+.5;
        for j=1:N;
            robotshow(robot,qbar{i}(:,j),color_code);
            xlabel('X [meters]'); ylabel('Y [meters]'); title('Optimal Trajectory');
        end
    end
    hold off

    more_qf=input('enter 0 to stop, 1 to continue: ');

end
%
% save path
%

trajpath=qfinal(1:2,:);
waypoints=vecnorm(diff(trajpath')');
waypointslength=[0 cumsum(waypoints)];
pathlength=sum(waypoints);
pathvel=1; % m/s
ts=.5;
lambda=(0:pathvel*ts:pathlength);n_l=length(lambda);
despath=zeros(2,n_l);
despath(1,:)=interp1(waypointslength,trajpath(1,:),lambda);
despath(2,:)=interp1(waypointslength,trajpath(2,:),lambda);
figure(50);
plot(trajpath(1,:),trajpath(2,:),'x-',despath(1,:),despath(2,:),'linewidth',2);
view(-90,90);axis([-1 11 -1 11]);
xlabel('X [meters]'); ylabel('Y [meters]'); title('Calculated Trajectory and Interpolated Trajectory');
save trajoptpath despath
% reshape xbar and generate the q vs. time matrix

function q=xbar_reshape(xbar,q0,n,N)%,robot)
    xflat=reshape(xbar,n,N);
    xdiff=diff(xflat')';
    q3=atan2(xdiff(2,:),xdiff(1,:));
    q=[xflat;[q0(3) q3]];
    %hold on;for i=1:N;robotshow(robot,q(:,i));end
end
