%
% penestrationdist.m: calculation of 2D overlap area between two polytopes
%
% input:
%   robot = planar robot object
%   q = planar robot pose
%   colobj = collision objects
%   i = index of the collision object
%
% output:
%   d = overlap area
%   polyoverlap = overlap polytope
%   colpoly = collision object polytope
%   robotpoly = robot polytope
%

function [d,polyoverlap,colpoly,robotpoly]=penetrationdist(robot,q,colobj,i)

d=0;
if colobj.type(i)==1
    vertices=[colobj.size{i}(1) -colobj.size{i}(2);
        colobj.size{i}(1) colobj.size{i}(2);
        -colobj.size{i}(1) colobj.size{i}(2);
        -colobj.size{i}(1) -colobj.size{i}(2)]'/2;
    vertices=(colobj.ori{i}(1:2,1:2)*vertices)+colobj.pos{i}(1:2);    
elseif colobj.type(i)==2
    N=20;th=(0:2*pi/N:2*pi*((N-1)/N));
    vertices=colobj.size{i}(1)*[cos(th);sin(th)];
    vertices=(vertices+colobj.pos{i}(1:2));    
end

N=20;th=(0:2*pi/N:2*pi*((N-1)/N));
robotvert=robot.Radius*[cos(th);sin(th)]+q(1:2);

colpoly=polyshape(vertices');
robotpoly=polyshape(robotvert');

polyoverlap=intersect(colpoly,robotpoly);
d=area(polyoverlap);

end