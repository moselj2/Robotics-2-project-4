%
% trajiter_EP.m
%
% trajectory iteration algorithm for path planning using the exterior
% penalty function approach
% 
% input:
%   robot = robot collision object
%   colobj = structure of collision objects in environment
%   ubar0 = initial guess of input trajectory
%   x0 = initial state
%   xf = final state
%   epsilon = regularization parameter for Newton update
%   alpha0 = maximum step size
%   jmax = max # of iterations
%   mu = strenght of the exterior penalty function
%   dumx = max step size for ubar update in each iteration
% 
% output
%   ubar = input trajectory (iteration history)
%   xbar = state trajectory (iteration history)
%   alpha = update parameters in line search
%   Bbar = mapping between ubar and xbar (xbar = x0bar + Bbar ubar)
%

function [ubar,xbar,alpha,Bbar]=...
    trajiter_EP(robot,colobj,ubar0,x0,xf,epsilon,alpha0,jmax,mu,dumx)

% get various array lengths

n=length(x0);
Nu=length(ubar0);
N=Nu/n;

% mapping from ubar to the final state
BN=Bfun(N,n,N);

% set up storage areas
x0bar=kron(ones(N,1),x0);
ubar=zeros(Nu,jmax);
xbar=zeros(n*N,jmax);
ubar(:,1)=ubar0;

Bbar=zeros(n*N,Nu);
for i=1:N
    Bbar((i-1)*n+1:i*n,:)=Bfun(i,n,N);    
end

% initial state trajectory
xbar(:,1)=x0bar+Bbar*ubar(:,1);
showx(xbar(:,1),n,robot);

A=zeros(N,Nu);
b=zeros(N,1);
dmin=.2; % range in which obstacles are considered
delta=[1;1]*1e-6; % constants used for numerical gradient calculation

% iteration of the input trajectory
for j=1:jmax-1    

% calculation of exterior penalty function gradient using overlap area
    gradu=zeros(1,n*N);
% check for each state stepa    
    for k=1:N
        Bk=Bfun(k,n,N);
        xk=x0+Bk*ubar(:,j);
        qk=[xk;0];
        [isInt,dist,wp]=colcheck(robot,qk,colobj);
        % if there is collision, add gradient 
        ind=find(isInt>0);
        g=zeros(1,n);
        for i=1:length(ind)
           g = g + grad_d(robot,qk,colobj,ind(i),delta);
        end
        gradu=gradu+g*Bk;
    end

    % gradient descent approach 
    du = -BN'*(x0+BN*ubar(:,j)-xf)-mu*gradu';
    % Newton's update
    %du = -inv(BN'*BN+epsilon*eye(Nu,Nu))*BN'*(BN*ubar(:,j)+x0-xf)-mu*gradu';

    % bisection search to find the best step size
    alpha(j)=bisectionsearch(.001,.99,ubar(:,j),du,BN,x0,xf,robot,colobj,mu);            
    % show step size
    disp(sprintf('alpha = %g',alpha(j)));
    % update input trajectory
    ubar(:,j+1)=ubar(:,j)+alpha(j)*du;
    % compute state trajectory
    xbar(:,j+1)=x0bar+Bbar*ubar(:,j+1);
    % display final state error cost and collision cost
    [c_state,c_col]=totalcost(ubar(:,j+1),BN,x0,xf,robot,colobj);
    disp(sprintf('xf error = %g, collision cost = %g',...
        c_state,c_col));
    disp((x0+BN*ubar(:,j+1))');
    showx(xbar(:,j+1),n,robot);
    if (c_state<1e-3)&&(c_col<1e-6);
        xbar(:,jmax)=xbar(:,j+1);
        ubar(:,jmax)=ubar(:,j+1);
        break;
    end
end

end

%
% cost calculation
%

function [c_state,c_col]=totalcost(u,BN,x0,xf,robot,colobj)

    n=size(BN,1);N=length(u)/n;

    % final state cost
    c_state=0.5*norm(x0+BN*u-xf)^2;
    
    c_col=0;
    for k=1:N
        Bk=Bfun(k,n,N);
        xk=x0+Bk*u;
        qk=[xk;0];
        [isInt,dist,wp]=colcheck(robot,qk,colobj);
        % if collision, use overlapping area for cost
        ind=find(isInt>0);
        for i=1:length(ind)
            [d,polyoverlap,colpoly,robotpoly]=...
                penetrationdist(robot,qk,colobj,ind(i));
            c_col=c_col+d;
        end
    end
    
end

%
% binary search for best step size
%
function a=bisectionsearch(a1init,a2init,u0,du,BN,x0,xf,robot,colobj,mu)

    n=size(BN,1);N=length(u0)/n;
    
    imax=10;amin=.01;i=1;

    a1=a1init;a2=a2init;
    a=a2init;
    
    % find alpha with the lowest total cost
    u2=u0+a2*du;
    [c_state,c_col]=totalcost(u2,BN,x0,xf,robot,colobj);
    c2=c_state+mu*c_col;
    u1=u0+a1*du;
    [c_state,c_col]=totalcost(u1,BN,x0,xf,robot,colobj);
    c1=c_state+mu*c_col;
    
    while (i<imax)&&((a2-a1)>amin)                
        if c1 < c2
            a2 = a2 - (a2-a1)/2 ;
            u2=u0+a2*du;
            [c_state,c_col]=totalcost(u2,BN,x0,xf,robot,colobj);
            c2=c_state+mu*c_col;
        else
            a1 = a1 + (a2-a1)/2 ;
            u1=u0+a1*du;        
            [c_state,c_col]=totalcost(u1,BN,x0,xf,robot,colobj);
            c1=c_state+mu*c_col;        
        end
%        disp([c1 c2]);
        i=i+1;
    end
%    disp('a1 a2');
%    disp([a1 a2]);
    a=(a2-a1)/2+a1;
    
end

% 
% visualize robot path
%
function showx(xbar,n,robot)

Nx = length(xbar);

colorcode=rand(1,3);
for i=1:Nx/n
    q=[xbar((i-1)*n+1:i*n);0];
    robotshow(robot,q,colorcode);
end

end

%
% mapping from ubar to xk
%
function Bk=Bfun(k,n,N)

Bk=zeros(n,N*n);

for i=1:k
    Bk(:,(i-1)*n+1:i*n)=eye(n,n);
end

end

%
% grad_d.m: numerical gradient of overlap area
%
% input:
%   robot = planar robot object
%   q = planar robot pose
%   colobj = collision objects
%   k = index of the collision object
%   delta = step size for gradient calculation (same size as q)
%
% output:
%   g = gradient as a row vector
%
function g = grad_d(robot,q,colobj,k,delta)

for i = 1:2
    
    u = q;
    u(i) = q(i) + delta(i);
    [d1,polyoverlap,colpoly,robotpoly]=penetrationdist(robot,u,colobj,k);
    u(i) = q(i) - delta(i);
    [d2,polyoverlap,colpoly,robotpoly]=penetrationdist(robot,u,colobj,k);
    % partial derivatives in column vector
    g(1,i) = (d1 - d2) / (2 * delta(i));
    
end

end
