%
% 2D formation control example based on the relative pose in a room
% 
%
% contact force
%

% contact location
Pci_q=[10,80,190,260]*pi/180;
%Pci_q=[10,30]*pi/180;
[Pci,e_ni]=contact_gen(Pci_q,load_x/2,load_y/2);

Pcorner=[load_x load_x -load_x -load_x load_x;...
    load_y -load_y -load_y load_y load_y]/2;
figure(60);plot(Pcorner(1,:),Pcorner(2,:),Pci(1,:),Pci(2,:),'x',...
    'LineWidth',2);
axis([-1,1,-1,1]);


% grasp map
K=[0 -1;1 0]; % planar cross product
m=length(Pci_q); % # of fingers

for k=1:N
    R=rot2(xc(3,k));
    Pci_0=R*Pci;
    Pci_0_perp=K*Pci_0;
    e_ni_0=R*e_ni;
    % rigid grasp
    G1{k}=zeros(3,2*m);
    for i=1:m
        G1{k}(1,(i-1)*2+1:2*i)=Pci_0_perp(:,i)';
        G1{k}(2:3,(i-1)*2+1:2*i)=eye(2);
    end
    % >>> *****
    % how to choose etaS so eta_n_1 (projected normal force at contact) is
    % always positive (pointing inward)
    % >>> *****
    %etaS=-20;
    etaS=0;
    eta_1(:,k)=pinv(G1{k})*etaC(:,k)+etaS*null(G1{k})*ones(2*m-3,1);
    for i=1:m
        eta_n_1(i,k)=e_ni_0(:,i)'*eta_1((i-1)*2+1:2*i,k);
    end
    % point contact without friction
    G2{k}=zeros(3,m);
    for i=1:m
        G2{k}(:,i)=G1{k}(:,(i-1)*2+1:2*i)*e_ni_0(:,i);
    end

    eta_2(:,k)=pinv(G2{k})*etaC(:,k);

    % point contact with friction
    phi=pi/4*ones(1,m); % friction cone
    G3{k}=zeros(3,2*m);
    for i=1:m
        G3{k}(:,(i-1)*2+1:2*i)=G1{k}(:,(i-1)*2+1:2*i)*...
            [rot2(phi(i))*e_ni_0(:,i) rot2(-phi(i))*e_ni_0(:,i)];
    end

    eta_3(:,k)=pinv(G3{k})*etaC(:,k);
end

figure(21);plot(t(1:end-1),eta_n_1);legend('1','2','3','4'); title('Rigid Grasp Normal Force')
figure(22);plot(t(1:end-1),eta_2);legend('1','2','3','4'); title('Frictionless Grasp Normal Force')
figure(23);plot(t(1:end-1),eta_3);legend('1','2','3','4'); title('Friction Grasp Normal Force')

%
% grasping robots location
% 

%
% generate contacts based on load dimension and angle
%
function [P,Pn]=contact_gen(q,a,b)

P=zeros(2,length(q));
Pn=P;
for i=1:length(q)
    if abs(b*tan(q(i)))<a
        if(abs(q(i))<pi/2)
            P(1,i)=b*tan(q(i));
            P(2,i)=b;
            Pn(:,i)=[-1;0];
        else
            P(1,i)=-b*tan(q(i));
            P(2,i)=-b;
            Pn(:,i)=[1;0];
        end
    else
        if (q(i)<pi)&&(q(i)>0)
            P(1,i)=a;
            P(2,i)=a*tan(pi/2-q(i));
            Pn(:,i)=[0;-1];
        else
            P(1,i)=-a;
            P(2,i)=-a*tan(pi/2-q(i));
            Pn(:,i)=[0;1];
        end        
    end
end
end

%
% planar rotation
%

function R=rot2(q)

R=[cos(q) -sin(q); sin(q) cos(q)];

end 
