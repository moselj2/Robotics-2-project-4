%
% 2D formation control example based on the relative pose in a room
% 
%
% contact force
%
%clear all;close all;
%load loadpath
%load trajoptpath
% contact location
m=20;% max # of fingers
Pci_q=[10,190,80,260]*pi/180;
%Pci_q=[80,170]*pi/180;
%Pci_q=(rand(1,m)-.5)*2*pi;
%Pci_q(find(abs(diff(sort(Pci_q)))<.5))=[];
m=length(Pci_q);

[Pci,e_ni]=contact_gen(Pci_q,load_x/2,load_y/2);

Pcorner=[load_x load_x -load_x -load_x load_x;...
    load_y -load_y -load_y load_y load_y]/2;

% choose # of fingers
%m=10;
%Pci=Pci(:,1:m);
%e_ni=e_ni(:,1:m);
% visualization of the load with robots attached in load frame
figure(60);plot(Pcorner(1,:),Pcorner(2,:),Pci(1,:),Pci(2,:),'x',...
    'LineWidth',2);
axis([-1,1,-1,1]);

% show room and load motion with robots attached
figure(40);
hold on;
roomshow(colobj,40);axis('square');
view(-90,90);axis([-1 11 -1 11 0 4]);
%for i=1:3:31;
for i=1:3:61;
    Pcorner0=rot2(xc(1,i))*Pcorner+xc(2:3,i);
    Pci0=rot2(xc(1,i))*Pci+xc(2:3,i);
    plot(Pcorner0(1,:),Pcorner0(2,:),Pci0(1,:),Pci0(2,:),'x','LineWidth',2);
    xlabel('x [m]'); ylabel('y [m]'); title('Load Motion w/ Grasp Map')
end;hold off

% grasp map
K=[0 -1;1 0]; % planar cross product
%m=length(Pci_q); % # of fingers
%m=2;
N=length(xc)-1;
for k=1:N
    R=rot2(xc(3,k));
    Pci_0=R*Pci;
    Pci_0_perp=K*Pci_0;
    Pci_0_perp=hat([0;0;1])*[Pci_0;zeros(1,m)];
    Pci_0_perp=Pci_0_perp(1:2,:);
    e_ni_0=R*e_ni;
    e_ti_0=hat([0;0;1])*[e_ni_0;zeros(1,m)];
    e_ti_0=e_ti_0(1:2,:);
    % rigid grasp
    G1{k}=zeros(3,2*m);
    for i=1:m
        G1{k}(1,(i-1)*2+1:2*i)=Pci_0_perp(:,i)';
        G1{k}(2:3,(i-1)*2+1:2*i)=eye(2);
        G1_p{k}(:,(i-1)*3+1:3*i)=G1{k}(:,(i-1)*2+1:2*i)*...
            [e_ni_0(:,i) e_ti_0(:,i) -e_ti_0(:,i)];
    end    
    % >>> *****
    % choose etaS so eta_n_1 (projected normal force at contact) is
    % always positive (pointing inward)
    % >>> *****
    mG1=size(G1_p{k},2);
    % minimizing ||G * x||^2, x>0
    [X_a,FVAL_a,EXITFLAG,OUTPUT] = ...
        quadprog(G1_p{k}'*G1_p{k},zeros(mG1,1),-eye(mG1),-ones(mG1,1));
    % minimizing ||x||^2 subject to G * x = 0, x>0
    [X_b,FVAL_b,EXITFLAG,OUTPUT] = ...
        quadprog(eye(mG1),zeros(mG1,1),-eye(mG1),-ones(mG1,1),...
        G1_p{k},zeros(3,1));
    if FVAL_a>.1;disp('^^^ NO FORCE CLOSURE GRASP (G1)^^^');%return;end
    end
    if isempty(X_b);disp('^^^ NO FORCE CLOSURE GRASP (G1) ^^^');%return;end
    end
    %
    % parameterized function
    fun = @(x,eta_m,eta_s) -min(min(eta_m+eta_s*x),0); 
    x=(0:.1:10);
    eta_m=pinv(G1_p{k})*etaC(:,k);
    for i=1:m
        i_1=(i-1)*3+1:3*i;
        x_a=fun(x,eta_m(i_1),X_a(i_1));
        x_b=fun(x,eta_m(i_1),X_b(i_1));
        ind=find(x_a>0);alpha_a(i)=x_a(min(ind));
        ind=find(x_b>0);alpha_b(i)=x_b(min(ind));
    end
    % minimum amount of null space component
    %alpha_a = fminbnd(@(x) fun(x,pinv(G1_p{k})*etaC(:,k),X_a),0,10);
    %alpha_b = fminbnd(@(x) fun(x,pinv(G1_p{k})*etaC(:,k),X_b),0,10);
    eta_a=pinv(G1_p{k})*etaC(:,k)+max(alpha_a)*X_a;
    eta_b=pinv(G1_p{k})*etaC(:,k)+max(alpha_b)*X_b;    
    for i=1:m
        eta_n_1_a(i,k)=eta_a((i-1)*3+1);
        eta_n_1_b(i,k)=eta_b((i-1)*3+1);
    end    
    % point contact without friction
    %G2{k}=zeros(3,m);
    %for i=1:m
    %    G2{k}(:,i)=G1{k}(:,(i-1)*2+1:2*i)*e_ni_0(:,i);
    %end
    % minimizing ||G * x||^2, x>0
    %mG2=size(G2{k},2);
    %[X_a,FVAL_a,EXITFLAG,OUTPUT] = ...
    %    quadprog(G2{k}'*G2{k},zeros(mG2,1),-eye(mG2),-ones(mG2,1));
    % minimizing ||x||^2 subject to G * x = 0, x>0
    %[X_b,FVAL_b,EXITFLAG,OUTPUT] = ...
    %    quadprog(eye(mG2),zeros(mG2,1),-eye(mG2),-ones(mG2,1),...
    %    G2{k},zeros(3,1));
    %if FVAL_a>.1;disp('^^^ NO FORCE CLOSURE GRASP (G2)^^^');return;end
    %if isempty(X_b);disp('^^^ NO FORCE CLOSURE GRASP (G2)^^^');return;end
    %
    % parameterized function
    %fun = @(x,eta_m,eta_s) -min(min(eta_m+eta_s*x),0); 
    %x=(0:.1:10);
    %eta_m=pinv(G2{k})*etaC(:,k);
    %x_a=fun(x,eta_m,X_a);
    %x_b=fun(x,eta_m,X_b);
    %ind=find(x_a>0);alpha_a=x_a(min(ind));
    %ind=find(x_b>0);alpha_b=x_b(min(ind));
    % minimum amount of null space component
    %alpha_a = fminbnd(@(x) fun(x,pinv(G1_p{k})*etaC(:,k),X_a),0,10);
    %alpha_b = fminbnd(@(x) fun(x,pinv(G1_p{k})*etaC(:,k),X_b),0,10);
    %eta2_a(:,k)=pinv(G2{k})*etaC(:,k)+max(alpha_a)*X_a;
    %eta2_b(:,k)=pinv(G2{k})*etaC(:,k)+max(alpha_b)*X_b;    
    %
    % point contact with friction
    %
    phi=pi/4*ones(1,m); % friction cone
    G3{k}=zeros(3,2*m);
    for i=1:m
        G3{k}(:,(i-1)*2+1:2*i)=G1{k}(:,(i-1)*2+1:2*i)*...
            [rot2(phi(i))*e_ni_0(:,i) rot2(-phi(i))*e_ni_0(:,i)];
    end   
    m3=size(G3{k},2);
    % minimizing ||G * x||^2, x>0
    [X_a,FVAL,EXITFLAG,OUTPUT] = quadprog(G3{k}'*G3{k},zeros(m3,1),-eye(m3),-ones(m3,1));
    % minimizing ||x||^2 subject to G * x = 0, x>0
    [X_b,FVAL1,EXITFLAG,OUTPUT] = quadprog(eye(m3),zeros(m3,1),-eye(m3),-ones(m3,1),G3{k},zeros(3,1));



    if FVAL_a>.1;disp('^^^ NO FORCE CLOSURE GRASP (G3)^^^');return;end
    if isempty(X_b);disp('^^^ NO FORCE CLOSURE GRASP (G3)^^^');return;end
    fun = @(x,eta_m,eta_s) -min(min(eta_m+eta_s*x),0);  % The parameterized function.
    x=(0:.1:10);

    alpha_a = fminbnd(@(x) fun(x,pinv(G3{k})*etaC(:,k),X_a),0,1);
    alpha_b = fminbnd(@(x) fun(x,pinv(G3{k})*etaC(:,k),X_b),0,1);
    %eta_m=pinv(G3{k})*etaC(:,k);
    %for i=1:m
    %    i_1=(i-1)*3+1:3*i;
    %    x_a=fun(x,eta_m(i_1),X_a(i_1));
    %    %x_a=fun(x,pinv(G3{k})*etaC(:,k),X_a(i_1));
    %    x_b=fun(x,eta_m(i_1),X_b(i_1));
    %    %x_b=fun(x,pinv(G3{k})*etaC(:,k),X_b(i_1));
    %    ind=find(x_a>0);alpha_a(i)=x_a(min(ind));
    %    ind=find(x_b>0);alpha_b(i)=x_b(min(ind));
    %end

    eta3_a(:,k)=pinv(G3{k})*etaC(:,k)+max(alpha_a)*X_a;
    eta3_b(:,k)=pinv(G3{k})*etaC(:,k)+max(alpha_b)*X_b; 

    eta3_a_combined(:,k)=[eta3_a(1,k)*sin(pi/4)+eta3_a(2,k)*sin(pi/4);
                    eta3_a(3,k)*sin(pi/4)+eta3_a(4,k)*sin(pi/4);
                    eta3_a(5,k)*sin(pi/4)+eta3_a(6,k)*sin(pi/4);
                    eta3_a(7,k)*sin(pi/4)+eta3_a(8,k)*sin(pi/4)];

   eta3_b_combined(:,k)=[eta3_b(1,k)*sin(pi/4)+eta3_b(2,k)*sin(pi/4);
                    eta3_b(3,k)*sin(pi/4)+eta3_b(4,k)*sin(pi/4);
                    eta3_b(5,k)*sin(pi/4)+eta3_b(6,k)*sin(pi/4);
                    eta3_b(7,k)*sin(pi/4)+eta3_b(8,k)*sin(pi/4)];

end

%figure(21);plot(t(1:end-1),eta_n_1_a,'linewidth',2);
%title('rigid grasp normal force: solution 1')
%legend('1','2','3','4');
%figure(22);plot(t(1:end-1),eta_n_1_b,'linewidth',2);
%title('rigid grasp normal force: solution 2')
%legend('1','2','3','4');

%figure(31);plot(t(1:end-1),eta2_a,'linewidth',2);
%title('frictionless grasp normal force: solution 1')
%legend('1','2','3','4');
%figure(32);plot(t(1:end-1),eta2_b,'linewidth',2);
% title('frictionless grasp normal force: solution 2')
% legend('1','2','3','4');

 figure(41);plot(t(1:end-1),eta3_a_combined,'linewidth',2);
title('friction grasp normal force: solution 1')
legend('1','2','3','4');
figure(42);plot(t(1:end-1),eta3_b_combined,'linewidth',2);
 title('friction grasp normal force: solution 2')
 legend('1','2','3','4');

%
function [P,Pn]=contact_gen(q,a,b)

P=zeros(2,length(q));
Pn=P;
for i=1:length(q)
    if abs(b*tan(q(i)))<a
        if(abs(q(i))<pi/2)
            P(1,i)=b*tan(q(i));
            P(2,i)=b;
            Pn(:,i)=[-1;0];
        else
            P(1,i)=-b*tan(q(i));
            P(2,i)=-b;
            Pn(:,i)=[1;0];
        end
    else
        if (q(i)<pi)&&(q(i)>0)
            P(1,i)=a;
            P(2,i)=a*tan(pi/2-q(i));
            Pn(:,i)=[0;-1];
        else
            P(1,i)=-a;
            P(2,i)=-a*tan(pi/2-q(i));
            Pn(:,i)=[0;1];
        end        
    end
end
end

%
% planar rotation
%

function R=rot2(q)

R=[cos(q) -sin(q); sin(q) cos(q)];

end 
